// ========== 1. Бургер-меню для мобільних ==========
const burger = document.getElementById('burgerBtn');
const navMenu = document.getElementById('navMenu');

if (burger) {
    burger.addEventListener('click', () => {
        navMenu.classList.toggle('active');
    });
}

// ========== 2. Робота з формою запису + LocalStorage ==========
// Функція збереження запису
function saveBookingToLocalStorage(booking) {
    let bookings = JSON.parse(localStorage.getItem('beestudio_bookings')) || [];
    bookings.push(booking);
    localStorage.setItem('beestudio_bookings', JSON.stringify(bookings));
}

// Функція відображення збережених записів на сторінці booking.html
function displayBookings() {
    const container = document.getElementById('bookingsList');
    if (!container) return; // якщо сторінка не booking — ігноруємо
    
    let bookings = JSON.parse(localStorage.getItem('beestudio_bookings')) || [];
    if (bookings.length === 0) {
        container.innerHTML = '<p>Немає активних записів</p>';
        return;
    }
    
    let html = '<ul>';
    bookings.forEach((b, idx) => {
        html += `<li><strong>${b.name}</strong> — ${b.service}, ${b.date} о ${b.time}, тел: ${b.phone}</li>`;
    });
    html += '</ul>';
    container.innerHTML = html;
}

// Валідація форми
const form = document.getElementById('bookingForm');
if (form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Отримуємо значення
        const name = document.getElementById('name').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const service = document.getElementById('service').value;
        const date = document.getElementById('date').value;
        const time = document.getElementById('time').value;
        
        let isValid = true;
        
        // Перевірка імені (не порожнє, тільки букви та пробіли)
        const nameRegex = /^[A-Za-zА-Яа-яЇїІіЄєҐґ\s]{2,}$/;
        if (!nameRegex.test(name)) {
            document.getElementById('nameError').innerText = "Введіть коректне ім'я (мінімум 2 літери)";
            isValid = false;
        } else {
            document.getElementById('nameError').innerText = "";
        }
        
        // Перевірка телефону (український формат)
        const phoneRegex = /^\+?38?0\d{9}$/;
        if (!phoneRegex.test(phone) && !/^0\d{9}$/.test(phone)) {
            document.getElementById('phoneError').innerText = "Введіть номер телефону (10 цифр, наприклад 0991234567 або +380991234567)";
            isValid = false;
        } else {
            document.getElementById('phoneError').innerText = "";
        }
        
        if (!date) {
            alert("Оберіть дату");
            isValid = false;
        }
        if (!time) {
            alert("Оберіть час");
            isValid = false;
        }
        
        if (isValid) {
            // Створюємо об'єкт запису
            const bookingData = {
                name: name,
                phone: phone,
                service: service,
                date: date,
                time: time,
                timestamp: new Date().toISOString()
            };
            
            // Зберігаємо в LocalStorage
            saveBookingToLocalStorage(bookingData);
            
            // Показуємо повідомлення
            const msgDiv = document.getElementById('message');
            msgDiv.innerHTML = " Ви успішно записані! Ми передзвонимо для підтвердження.";
            msgDiv.style.color = "#4caf50";
            
            // Очистити форму
            form.reset();
            
            // Оновити список записів на сторінці
            displayBookings();
            
            // Через 4 секунди прибрати повідомлення
            setTimeout(() => {
                msgDiv.innerHTML = "";
            }, 4000);
        }
    });
}

// Викликаємо відображення записів, коли завантажилось DOM
document.addEventListener('DOMContentLoaded', () => {
    displayBookings();
});